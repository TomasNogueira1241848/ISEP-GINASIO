<?php include '../../includes/header.php'; ?>
<?php include '../../includes/nav.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <!-- Conteúdo Principal -->
<main class="col-md-9 col-lg-10 p-4">
 <section>
 <h2>Planos de Treino</h2>
 <p>Veja todos os planos de treino que temos para si.</p>
 </section>
</main>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
